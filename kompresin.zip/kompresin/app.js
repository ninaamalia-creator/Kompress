/* Kompresin — kompres file di browser, format tetap sama. */
'use strict';

const $ = (s) => document.querySelector(s);

const PRESETS = {
  ringan:   { quality: 80, maxDim: 3000, dpi: 150, pngColors: 0,   hint: 'Kualitas hampir tidak berubah, pengurangan ukuran kecil–sedang.' },
  seimbang: { quality: 65, maxDim: 2000, dpi: 120, pngColors: 256, hint: 'Pilihan terbaik untuk kebanyakan file: jauh lebih kecil, tetap jelas dibaca.' },
  maksimal: { quality: 45, maxDim: 1400, dpi: 90,  pngColors: 128, hint: 'Ukuran sekecil mungkin. Cocok untuk kirim via WA/email atau batas upload ketat.' },
};

let level = 'seimbang';
const items = [];          // { file, el, result, name }
let queue = Promise.resolve();

if (window.pdfjsLib) {
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

/* ---------- pengaturan ---------- */
function applyPreset(name) {
  level = name;
  const p = PRESETS[name];
  document.querySelectorAll('#level button').forEach((b) => b.classList.toggle('on', b.dataset.v === name));
  $('#quality').value = p.quality;
  $('#maxDim').value = p.maxDim;
  $('#dpi').value = p.dpi;
  $('#qOut').textContent = p.quality + '%';
  $('#levelHint').textContent = p.hint;
}
function getOpts() {
  return {
    quality: clamp(+$('#quality').value, 10, 95) / 100,
    maxDim: clamp(+$('#maxDim').value || 2000, 320, 8000),
    dpi: clamp(+$('#dpi').value || 120, 50, 300),
    pngColors: PRESETS[level].pngColors,
    pdfMode: $('#pdfMode').value,
  };
}
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
$('#level').addEventListener('click', (e) => { if (e.target.dataset.v) applyPreset(e.target.dataset.v); });
$('#quality').addEventListener('input', (e) => ($('#qOut').textContent = e.target.value + '%'));
applyPreset('seimbang');

/* ---------- input file ---------- */
const drop = $('#drop');
$('#picker').addEventListener('change', (e) => { addFiles(e.target.files); e.target.value = ''; });
['dragenter', 'dragover'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', (e) => addFiles(e.dataTransfer.files));

function kind(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (ext === 'pdf' || file.type === 'application/pdf') return 'pdf';
  if (['jpg', 'jpeg', 'png', 'webp'].includes(ext)) return 'img';
  if (['docx', 'xlsx', 'pptx', 'odt', 'ods', 'odp'].includes(ext)) return 'doc';
  return null;
}

function addFiles(fileList) {
  $('#listWrap').hidden = false;
  for (const file of fileList) {
    const el = $('#itemTpl').content.firstElementChild.cloneNode(true);
    const k = kind(file);
    const ext = file.name.split('.').pop().toLowerCase();
    el.querySelector('.badge').textContent = ext.slice(0, 4);
    el.querySelector('.badge').classList.add(k || 'x');
    el.querySelector('.name').textContent = file.name;
    const item = { file, el, result: null };
    items.push(item);
    $('#list').appendChild(el);
    if (!k) { setMeta(item, `${fmt(file.size)} · <span class="err">Format belum didukung</span>`); done(item); continue; }
    setMeta(item, `${fmt(file.size)} · menunggu…`);
    const opts = getOpts();
    queue = queue.then(() => processItem(item, k, opts));
  }
}

async function processItem(item, k, opts) {
  const { file } = item;
  setMeta(item, `${fmt(file.size)} · memproses…`);
  const progress = (p) => (item.el.querySelector('.bar i').style.width = Math.round(p * 100) + '%');
  try {
    let blob;
    if (k === 'img') blob = await compressImage(file, opts);
    else if (k === 'pdf') blob = await compressPdf(file, opts, progress);
    else blob = await compressOffice(file, opts, progress);

    if (!blob || blob.size >= file.size) {
      setMeta(item, `${fmt(file.size)} · <span class="warn">Sudah optimal, tidak bisa diperkecil lagi</span>`);
      item.result = null;
    } else {
      const saved = 1 - blob.size / file.size;
      item.result = blob;
      setMeta(item, `${fmt(file.size)} → <b>${fmt(blob.size)}</b> · <span class="ok">hemat ${Math.round(saved * 100)}%</span>`);
      const a = item.el.querySelector('.dl');
      a.href = URL.createObjectURL(blob);
      a.download = item.name = outName(file.name);
      a.hidden = false;
    }
  } catch (err) {
    console.error(err);
    const msg = /password|encrypt/i.test(String(err)) ? 'PDF terkunci password' : 'Gagal memproses file';
    setMeta(item, `${fmt(file.size)} · <span class="err">${msg}</span>`);
  }
  done(item);
}

function done(item) { item.el.classList.add('done'); updateTotal(); }
function setMeta(item, html) { item.el.querySelector('.meta').innerHTML = html; }
function outName(name) { return name.replace(/(\.[^.]+)$/, '-kecil$1'); }
function fmt(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(b < 10240 ? 1 : 0) + ' KB';
  return (b / 1048576).toFixed(2) + ' MB';
}
function updateTotal() {
  const ok = items.filter((i) => i.result);
  $('#dlAll').disabled = ok.length === 0;
  if (!ok.length) { $('#total').textContent = ''; return; }
  const before = ok.reduce((s, i) => s + i.file.size, 0);
  const after = ok.reduce((s, i) => s + i.result.size, 0);
  $('#total').textContent = `Total: ${fmt(before)} → ${fmt(after)} (hemat ${fmt(before - after)})`;
}

$('#dlAll').addEventListener('click', async () => {
  for (const i of items.filter((x) => x.result)) {
    i.el.querySelector('.dl').click();
    await new Promise((r) => setTimeout(r, 400)); // jeda agar browser tidak memblokir unduhan beruntun
  }
});
$('#clear').addEventListener('click', () => {
  items.forEach((i) => { const a = i.el.querySelector('.dl'); if (a.href) URL.revokeObjectURL(a.href); });
  items.length = 0; $('#list').innerHTML = ''; $('#listWrap').hidden = true; updateTotal();
});

/* ---------- gambar ---------- */
function canvasToBlob(canvas, type, q) {
  return new Promise((res) => canvas.toBlob(res, type, q));
}
function mimeOf(name, fallback) {
  const ext = name.split('.').pop().toLowerCase();
  return { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp' }[ext] || fallback;
}

/** Kompres satu gambar; hasil berformat sama dengan aslinya. */
async function compressImage(blob, opts, nameHint) {
  const type = mimeOf(nameHint || blob.name || '', blob.type);
  const bmp = await createImageBitmap(blob);
  const s = Math.min(1, opts.maxDim / Math.max(bmp.width, bmp.height));
  const w = Math.max(1, Math.round(bmp.width * s));
  const h = Math.max(1, Math.round(bmp.height * s));
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  if (type === 'image/jpeg') { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); }
  ctx.drawImage(bmp, 0, 0, w, h);
  bmp.close && bmp.close();

  if (type === 'image/png') {
    if (window.UPNG) {
      const data = ctx.getImageData(0, 0, w, h).data;
      const buf = UPNG.encode([data.buffer], w, h, opts.pngColors); // 0 = lossless, 256/128 = kuantisasi warna
      return new Blob([buf], { type: 'image/png' });
    }
    return canvasToBlob(c, 'image/png');
  }
  const out = await canvasToBlob(c, type, opts.quality);
  // Beberapa browser (mis. Safari lama) tidak bisa membuat WebP → jangan ganti format.
  return out && out.type === type ? out : null;
}

/* ---------- PDF ---------- */
async function compressPdf(file, opts, progress) {
  const buf = await file.arrayBuffer();
  const candidates = [];

  // 1) Optimasi struktur (teks tetap bisa dicari/disalin)
  if (opts.pdfMode !== 'gambar') {
    try {
      const doc = await PDFLib.PDFDocument.load(buf.slice(0), { updateMetadata: false });
      const bytes = await doc.save({ useObjectStreams: true });
      candidates.push(new Blob([bytes], { type: 'application/pdf' }));
    } catch (e) { if (opts.pdfMode === 'teks') throw e; }
  }

  // 2) Render ulang tiap halaman jadi JPEG (paling efektif untuk hasil scan/foto)
  if (opts.pdfMode !== 'teks') {
    const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(buf.slice(0)) }).promise;
    const out = await PDFLib.PDFDocument.create();
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const base = page.getViewport({ scale: 1 });
      let scale = opts.dpi / 72;
      const maxPx = 14e6; // batas aman ukuran canvas
      if (base.width * base.height * scale * scale > maxPx) scale = Math.sqrt(maxPx / (base.width * base.height));
      const vp = page.getViewport({ scale });
      canvas.width = Math.ceil(vp.width); canvas.height = Math.ceil(vp.height);
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
      const jpg = await canvasToBlob(canvas, 'image/jpeg', opts.quality);
      const img = await out.embedJpg(await jpg.arrayBuffer());
      const p = out.addPage([base.width, base.height]);
      p.drawImage(img, { x: 0, y: 0, width: base.width, height: base.height });
      page.cleanup();
      progress(i / pdf.numPages);
    }
    pdf.destroy();
    const bytes = await out.save({ useObjectStreams: true });
    candidates.push(new Blob([bytes], { type: 'application/pdf' }));
  }

  progress(1);
  return candidates.sort((a, b) => a.size - b.size)[0] || null;
}

/* ---------- DOCX / XLSX / PPTX / ODT dll. ---------- */
async function compressOffice(file, opts, progress) {
  const zip = await JSZip.loadAsync(file);
  const media = Object.values(zip.files).filter((f) => !f.dir && /\.(jpe?g|png)$/i.test(f.name));
  let n = 0;
  for (const f of media) {
    try {
      const original = await f.async('blob');
      const smaller = await compressImage(original, opts, f.name);
      if (smaller && smaller.size < original.size) zip.file(f.name, smaller);
    } catch (e) { /* lewati gambar yang tidak bisa dibaca (mis. EMF) */ }
    progress(++n / (media.length + 1));
  }
  // Dokumen OpenDocument mewajibkan file "mimetype" tidak terkompresi.
  if (zip.files['mimetype']) zip.file('mimetype', await zip.file('mimetype').async('string'), { compression: 'STORE' });
  const blob = await zip.generateAsync({
    type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 9 }, mimeType: file.type,
  });
  progress(1);
  return blob;
}

/* ---------- PWA (bisa dipasang & dipakai offline setelah dibuka sekali) ---------- */
if ('serviceWorker' in navigator && location.protocol === 'https:') {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
