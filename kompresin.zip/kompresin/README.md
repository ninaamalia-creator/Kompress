<p align="center"><img src="assets/icon-192.png" width="96" alt="Ikon Kompresin"></p>

# Kompresin

Aplikasi web untuk **memperkecil ukuran file tanpa mengubah formatnya** — PDF tetap PDF, JPG tetap JPG, DOCX tetap DOCX. Semua proses berjalan di browser, file **tidak diunggah ke server**.

## Format yang didukung

| Jenis | Cara kerja |
|---|---|
| **PDF** | Mode *Pintar* mencoba dua cara lalu memilih hasil terkecil: (1) optimasi struktur PDF — teks tetap bisa dicari/disalin; (2) render ulang tiap halaman jadi JPEG dengan DPI & kualitas pilihan — sangat efektif untuk hasil scan/foto. |
| **JPG / WebP** | Encode ulang dengan kualitas pilihan + perkecil dimensi bila terlalu besar. |
| **PNG** | Kuantisasi warna (seperti TinyPNG) + perkecil dimensi. Transparansi tetap terjaga. |
| **DOCX / XLSX / PPTX / ODT / ODS / ODP** | Gambar di dalam dokumen dikompres ulang, lalu dokumen dikemas ulang dengan kompresi maksimal. Isi & tata letak tidak berubah. |

Jika hasil tidak lebih kecil dari aslinya, aplikasi memberi tahu bahwa file sudah optimal (file asli tidak diganti).

## Tingkat kompresi

- **Ringan** — kualitas hampir sama, pengurangan kecil–sedang.
- **Seimbang** — default, cocok untuk kebanyakan file.
- **Maksimal** — sekecil mungkin, untuk batas upload yang ketat (mis. 200 KB / 500 KB).

Bisa diatur lebih detail di *Pengaturan lanjutan* (kualitas, ukuran maksimal gambar, DPI PDF, mode PDF).

## Cara memasang di GitHub

1. Buat repositori baru di GitHub, misalnya `kompresin`.
2. Unggah semua isi folder ini (atau `git push`):
   ```bash
   git init && git add . && git commit -m "Kompresin"
   git branch -M main
   git remote add origin https://github.com/USERNAME/kompresin.git
   git push -u origin main
   ```
3. Buka **Settings → Pages**, pada *Source* pilih **GitHub Actions**.
4. Tunggu workflow *Deploy ke GitHub Pages* selesai (tab **Actions**). Aplikasi tersedia di
   `https://USERNAME.github.io/kompresin/`.

Setelah dibuka, aplikasi bisa **dipasang di HP/laptop** (menu browser → *Instal aplikasi* / *Tambahkan ke layar utama*) dan tetap bisa dipakai offline.

## Menjalankan di komputer sendiri

```bash
python3 -m http.server 8000
# buka http://localhost:8000
```

## Teknologi

[pdf-lib](https://pdf-lib.js.org), [PDF.js](https://mozilla.github.io/pdf.js/), [JSZip](https://stuk.github.io/jszip/), [UPNG.js](https://github.com/photopea/UPNG.js) — dimuat dari CDN.

## Lisensi

MIT
